﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint04
{
    class Gnome
    {
        public string Name { get; set; }
        public string Beard { get; set; }
        public string Evil { get; set; }
        public int Temperament { get; set; }
        public string Race { get; set; }
    }
}
