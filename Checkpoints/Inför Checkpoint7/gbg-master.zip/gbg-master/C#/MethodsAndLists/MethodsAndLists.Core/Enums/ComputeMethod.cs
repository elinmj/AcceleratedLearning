﻿namespace MethodsAndLists.Core.Enums
{
    public enum ComputeMethod
    {
        Sum, Product
    }
}
