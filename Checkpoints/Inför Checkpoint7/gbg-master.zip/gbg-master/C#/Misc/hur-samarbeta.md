# Hur samarbeta?

## Startup möte

Ha ett längre möte (30min+) tillsammans offline. Papper och penna. Whiteboard. Diskutera. Se till att alla har en gemensam bild av projektet.

## Offline möte 

Planera in tider för offline möten på morgonen och efter lunch. Sitta en stund tillsammans (10min+) utan dator. 

Våga lägg tid på att ena gruppen och inte knappa.

## GIT

Använd GIT för att versionshantera. Det är utmanande i början men 

Checka in koden ofta.

## Olika nivår

Är du på en högre nivå: stötta dina kollegor, mentorroll 

Är du på en lägre nivå: våga be om hjälp

## Ändra fokus

Viktigaste är att gruppen som helhet utvecklas.

Viktigaste är inte slutresultatet.

## Teknisk feedback

Teknisk feedback > projektet

Om du känner behov av att komma ikapp så lägg nån timme per dag på det. Ta hjälp av läraren.