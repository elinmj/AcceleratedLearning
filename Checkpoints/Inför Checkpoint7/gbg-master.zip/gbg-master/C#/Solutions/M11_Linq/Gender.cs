﻿
namespace M11_Linq
{
    public enum Gender
    {
        Female, Male, Other
    }
}
