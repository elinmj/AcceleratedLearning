﻿using System;

namespace M11_Linq.DemoLinq
{
    class Show
    {
        public string Channel { get; set; }
        public TimeSpan StartAt { get; set; }
        public string Title { get; set; }
    }
}
