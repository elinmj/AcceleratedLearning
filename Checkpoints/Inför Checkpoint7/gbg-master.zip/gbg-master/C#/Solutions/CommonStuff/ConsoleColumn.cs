﻿using System;

namespace CommonStuff
{
    public class ConsoleColumn
    {
        public int Width { get; set; }
        public ConsoleColor Color { get; set; }
    }
}
