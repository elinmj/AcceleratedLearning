# Tips f�r checkpoint

�va p� att anv�nda metoder

�va p� uppgifterna i projektet *MethodsAndLists*

F�r Level 2: �va p� att skapa en metod och sedan ett testprojekt som verifierar att din metod funkar.
