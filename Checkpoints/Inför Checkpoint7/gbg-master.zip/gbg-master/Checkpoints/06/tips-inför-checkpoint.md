# Tips inf�r checkpoint

Kunna skapa en ny consoleapp med Entity Framework

(beh�ver inte t�nka p� flera projekt)

Via entity framework kunna
- Skapa en tabell
- L�gga till info i tabellen
- H�mta info fr�n tabellen

