# Tips inf�r checkpoint

�va p�:

* Modellera en databas (skapa tabeller, prim�rnycklar, relationer)

* Utifr�n C# g�ra insert, update, delete, select mot en tabell

* Skapa en DataAccess-klass som bara ansvarar f�r att kommunicera med databasen (som inte inneh�ller Console.Write ,Console.Read)

