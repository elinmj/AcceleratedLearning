
# CheckpointRooms - Rum

## Intro

L�mna bara in en version. Du kan b�rja direkt p� Level 2 om du vill.

## Tid 

2h

## Level 1

Anv�ndaren matar in rumsnamn tillsammans med storlek p� rummet. Storleken anges med en siffra samt texten "m2". Rummen ska separaras med pipetecknet: **|** 

Skriv ut rummen och skriv �ven ut vilket rum som �r st�rst samt dess storlek. (Du kan anta att bara ett rum �r st�rst)

L�s uppgiften genom att skapa en klass **Room** som du anv�nder i programmet (krav)

![](CheckpointRooms_2.png)


## Level 2

Anv�ndaren skriver nu rum i detta format:

    Rumsnamn Kvadratmeter LjusetP�EllerEj

T.ex

    Salong 15m2 On

Ljuset i ett rum �r antingen p� eller av: **On** eller **Off**.

Validera anv�ndarens input. Ge meddelande om anv�ndaren matar in p� fel format. 

N�r anv�ndaren matar in r�tt input s� skriv ut:
- Vilka rum som �r t�nda (om n�got) 
- Vilket rum som �r st�rst 
- Hur m�nga rum som har angivits

Upprepa s� anv�ndaren kan mata in rum flera g�nger. (se bilden)

Se nedan f�r hur datan ska presenteras.

![](CheckpointRooms_3.png)
