# Tips inf�r checkpoint

�va p�, se till att du �r trygg med grunderna i:

- Modellering av databas. 
- En till m�nga relationer. M�nga-till-m�nga-relationer.
- Primary keys och foreign keys
- SQL-kommandon (insert, update, delete, select, select med join)

