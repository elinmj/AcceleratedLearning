# Referenser - Databasmodellering

## Database Structure and Design Tutorial

Bra om datasbasmodellering. Processen, relationer, normalisering, index

https://www.lucidchart.com/pages/database-diagram/database-design

## Introduction to Database Design

Identifiera entiteter, relationer, attribut, nycklar, normalering. Bra. 

http://www.datanamic.com/support/lt-dez005-introduction-db-modeling.html

## 11 important database designing rules which I follow

Personliga tips fr�n Shivprasad fr�mst kring normalisering

https://www.codeproject.com/Articles/359654/important-database-designing-rules-which-I-fo