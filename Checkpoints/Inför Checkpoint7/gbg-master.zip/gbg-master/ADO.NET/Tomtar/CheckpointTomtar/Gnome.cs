﻿
namespace CheckpointTomtar
{
    public class Gnome
    {
        public string Name { get; set; }
        public bool HasBeard { get; set; }
        public bool IsEvil { get; set; }
        public int Temperament { get; set; }
        public string Race { get; set; }
    }
}
