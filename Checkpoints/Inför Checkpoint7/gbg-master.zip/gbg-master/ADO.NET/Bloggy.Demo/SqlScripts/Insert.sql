﻿
USE BlogPostDemo

-- Två bloggposter

INSERT INTO BlogPost (Author, Title) 
VALUES ('Lily', 'The sun is bright')

INSERT INTO BlogPost (Author, Title) 
VALUES ('Ethan', 'I will go swimming')

