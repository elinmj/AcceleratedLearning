# Referenser - ADO.NET

#### SqlConnection
https://www.dotnetperls.com/sqlconnection 	

#### SqlDataReader
https://www.dotnetperls.com/sqldatareader 	

#### SqlParameter
https://www.dotnetperls.com/sqlparameter 	

#### Ok, klassisk tutorial. Mycket text.
http://csharp-station.com/Tutorial/AdoDotNet 	