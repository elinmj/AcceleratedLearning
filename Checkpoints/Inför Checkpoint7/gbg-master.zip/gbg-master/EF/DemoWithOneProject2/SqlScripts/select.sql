﻿use DemoWithOneProject2
select * from Fruits
select * from FruitCategories