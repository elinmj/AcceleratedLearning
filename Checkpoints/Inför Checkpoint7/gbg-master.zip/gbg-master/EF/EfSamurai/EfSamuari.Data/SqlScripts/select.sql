﻿use EfSamurai
select * from Samurais
select * from BattleEvent
select * from BattleLog
select * from Battles
select * from Quotes
select * from SamuraiBattles
select * from SecretIdentity