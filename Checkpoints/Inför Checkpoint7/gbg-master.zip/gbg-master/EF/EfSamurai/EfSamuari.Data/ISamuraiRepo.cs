﻿namespace EfSamurai.Data
{
    public interface ISamuraiRepo
    {
        string GetFirstSamuraiName();
    }
}
