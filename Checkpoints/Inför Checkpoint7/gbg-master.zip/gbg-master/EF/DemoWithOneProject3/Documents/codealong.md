﻿# Codealong

Fortsätt på föregående projekt

## Diskussion

- En kundkorg. Vad har den för egenskaper?
- Relation mellan kundkorg och frukter/kategorier?

## Modellering

Lägg till FruitInBasket

Lägg till properties (listor) från fruit och basket

Testa att migrera (funkar ej)

Lägg till key i Context

Migerera

Kolla

## Övning

Lägg till två kundkorgar + frukter i korgarna. Uppdatera: AddCategoriesAndFruits

Kolla i databasen

## Övning

Visa innehållet i dina kundkorgar

Tips: visa DisplayBaskets och de gör GetAllBaskets och GetAllFruitsInBasket



