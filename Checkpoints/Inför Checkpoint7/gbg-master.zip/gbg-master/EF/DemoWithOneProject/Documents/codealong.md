﻿# Code along

## Diskutera

 - Kör programmet
 - Diskutera hur lösa (utan EF)

## Skapa databas

 - Fruit.cs
 - Microsoft.EntityFrameworkCore
 - Microsoft.EntityFrameworkCore.SqlServer
 - FruitContext
 - EnsureCreated
 - (kolla)

## Lägg till

 - Lägg till 
 - (kolla)

## Hämta
 
 - Hämta 
 - (kolla)