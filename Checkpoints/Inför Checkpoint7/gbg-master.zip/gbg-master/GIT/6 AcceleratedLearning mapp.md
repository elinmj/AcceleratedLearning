## Städa

Städa bland dina tidigare uppgifter. Ta bort kod som inte används. Flytta alla program till denna mapp:

	C:\Project\AcceleratedLearning

## Lägg upp dina projekt på github

- Skapa ett repo på github som du döper till **AcceleratedLearning**
- Skapa ett repo med SourceTree vid **C:\Project\AcceleratedLearning** 
- Lägg till en **ignore**-fil. Du kan sno denna:

	https://github.com/happy-bits/gbg/blob/master/.gitignore

- Stage. Commit. Push.
