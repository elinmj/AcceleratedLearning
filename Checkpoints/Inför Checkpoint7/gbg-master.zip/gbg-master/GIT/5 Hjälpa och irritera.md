# 5 Hj�lpa och irritera

## Skapa testprojekt

Kopiera en av dina tidigare C#-projekt till en mapp t.ex

	c:\Project\MyProject

Skapa ett repository. Push'a till github.

Bjud in 1-2 kollegor till ditt projekt. (I github: Settings => Collaborators)

## H�mta hem kollegans projekt

- H�mta hem en kollegas projekt mha Clone.
- Testk�r programmet.
- F�rs�k lista ut hur det funkar. 

## L�gg till kommentarer

- Jobba vidare med kollegans projekt.
- Skriv kommentarer i koden. G�r en commit med meddelandet �Added comments�

## Ge feedback

Jobba vidare med kollegans projekt.

Ge en eller flera f�rslag p� f�rb�ttringar. G�r det genom att skriva kommentarer med todo, t.ex:

// TODO: Anv�nd ett tydligare variabelnamn

Commit�a och push'a.

## Buggar och f�rb�ttringar

Jobba vidare med kollegans projekt.

Nu ska du g�ra ett par f�rb�ttringar och l�gga in en bugg. 

## R�tta

F�rs�k lista ut vilken/vilka buggar som din kollega har st�llt till med. R�tta till problemet.

Stage. Comit. Push