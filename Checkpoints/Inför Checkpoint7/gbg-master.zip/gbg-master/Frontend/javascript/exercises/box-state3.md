# box-state3.html - Röd kvadrat

- Om användaren trycker Next så gör kvadraten rödare (åt helrött)
- Om användaren trycker Previous så gör kvadraten mörkare (åt svart)

![](img/box3.png)


