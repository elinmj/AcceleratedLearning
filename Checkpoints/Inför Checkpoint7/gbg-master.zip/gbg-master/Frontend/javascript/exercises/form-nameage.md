# form-nameage.html - Ange namn och ålder ålder

- Användaren matar in sitt namn och ålder. Svara enligt bilden nedan.

- Om användaren matar in "Oscar" och "43" skriv "I like you!"

---

![](img/form-nameage.png)


