# box-state1.html - Tre knappar

- Om första knappen trycks ner visa röd rektangel.
- Om andra knappen trycks ner visa grön rektangel.
- Om tredje knappen trycks ner visa blå rektangel.

![](img/box1.png)
