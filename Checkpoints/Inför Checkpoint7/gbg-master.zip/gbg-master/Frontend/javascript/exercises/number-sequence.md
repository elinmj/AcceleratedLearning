﻿# number-sequence.html

Användaren matar in ett tal och trycker Ok.

Skriv ut tal från 1 upp till det angivna talet. 

![](img/number-sequence.png)

Tips: använd arrayer, push och join.