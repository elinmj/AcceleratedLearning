# Projekt � F�rsta dagen

# Intro

Vi b�rjar utbildningen med ett miniprojekt i grupp! 

# Uppgift

G� ihop i grupper med 3-4 i varje grupp. Ta fram en website med f�ljande inneh�ll:

* Gruppens namn
* Presentation av alla gruppmedlemmar:
    * Namn
    * Vem �r du?
    * Ett udda intresse (l�sa korsord, spela curling, rita enh�rningar)
    * G�rna bild
    
* Tre bra saker med f�rstudierna 

* Tre id�er som skulle f�rb�ttra f�rstudierna  

Anv�nd HTML, CSS, Javascript. 

Det �r helt ok att g� loss med animationer, bilder, ljud, extra-allt, eldar, blinkande texter och hoppande katter.

# Gruppindelning

3 4 4 4

# Tider

- 13.00 Start
- 15.30 Karma
- 16.20 Deadline
- 16.30 Redovisning
- 16.55 Avrundning

# Karma

Samling i klassrummet. 

Dela med ett tekniktips per grupp. (typ 1min per grupp)

# Deadline

Skapa en zip-fil av ditt projekt och ladda upp h�r i Canvas senast **kl 16.20** 

Tips: skicka zip-filen f�rst till en kompis och verifiera att sajten funkar p� hans/hennes dator ocks�. (d� undviker du att bilder och script �r fell�nkade)

# Redovisning

Demonstrera er sajt (och diskutera om era kommentarer kring f�rstudierna).

Visa n�gon del av koden.

5 minuter redovisning per grupp.

Tips

- https://www.w3schools.com/
- https://www.tutorialspoint.com/
- http://htmldog.com/guides/html/beginner/ 
- http://htmldog.com/guides/css/beginner/ 