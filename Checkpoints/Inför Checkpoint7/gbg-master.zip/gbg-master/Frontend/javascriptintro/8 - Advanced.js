﻿
function adv1() {

    const evens = [2, 4, 6, 8];

    // Använd "map" för att skapa en ny lista "odds" utifrån listan "evens"

}

function adv2() {

    const evens = [2, 4, 6, 8];

    // Använd "map" för att skapa en ny lista "--2--", "--4--", "--6--", "--8--"

}

function adv3() {

    const evens = [2, 4, 6, 8];

    // Använd "map" för att skapa en ny lista [{row:1, num:200}, {row:2, num:400} ...]

}


function adv4() {

    const evens = [2, 4, 6, 8];
    // Använd "forEach" för att skriva ut alla element i listan
}

function adv5() {

    // Gör om metoden så default för a är 30 och b är 40. 
    // alltså om t.ex sum(15) anropas så returneras 55
    function sum(a, b) {
        return a + b;
    }

}

function adv6() {

    // Skapa en funktion "sum" som summerar valfritt antal tal
    // Ex sum(2, 10, 3) ska returnera 15
    // Ex sum(2, 10) ska returnera 12
    // Använd "spread operator"

}

function adv7() {

    /* Skapa en funktion "supersum" som ska funka såhär:
   
       supersum("<", ">", 3, 4, 5);  ==>  "<12>"
       supersum("[", "]", 55, 2)     ==>  "[57]"
       supersum("A", "B", 6)         ==>  "A6B"

    */

}

function adv8() {

    /*
     Skapa metoden "starify" som ska funka såhär:

     starify("ab")           ==>   ["*a*", "*b*"]
     starify("XYZ")          ==>   ["*X*", "*Y*", "*Z*"]

    Använd "map" och "spread operator"
     */ 
}

function adv9() {

    let firstName = "Simon";
    let lastName = "Larsson";

    // Skapa objektet {firstName: "Simon", lastName: "Larsson"} på enklast möjliga sätt

}

function adv10() {
    /*
     Skapa ett objekt "myMath" som rymmer metoderna "addOne" och "double":

        myMath.addOne(100)   ==>   101
        myMath.double(100)   ==>   200
     */

}
