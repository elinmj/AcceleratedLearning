﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint02
{
    class Room
    {
        public string Name { set; get; }
        public int Area { set; get; }
        public string Lights { set; get; }
    }
}
