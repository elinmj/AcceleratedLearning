﻿namespace Checkpoint0._2Elin
{
    internal class CorrectFormat
    {
        private string v;

        public CorrectFormat(string v)
        {
            this.v = v;
        }
    }
}