﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWithOneProject2
{
    public class FruitInBasket
    { //För att modelera en mellantabell
        public int FruitId { get; set; }
        public Fruit Fruit { get; set; }

        public int BasketId { get; set; }
        public Basket Basket { get; set; }
    }
}
