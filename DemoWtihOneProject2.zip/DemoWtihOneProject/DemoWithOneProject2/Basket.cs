﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWithOneProject2
{
    public class Basket
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<FruitInBasket> FruitInBaskets { get; set; }
    }
}
