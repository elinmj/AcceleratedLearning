﻿select*from Fruits
select*from FruitCategories