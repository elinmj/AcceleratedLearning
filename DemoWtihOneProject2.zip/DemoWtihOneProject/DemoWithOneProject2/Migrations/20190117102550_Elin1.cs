﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DemoWithOneProject2.Migrations
{
    public partial class Elin1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FruitInBasket_Baskets_BasketId",
                table: "FruitInBasket");

            migrationBuilder.DropForeignKey(
                name: "FK_FruitInBasket_Fruits_FruitId",
                table: "FruitInBasket");

            migrationBuilder.DropPrimaryKey(
                name: "PK_FruitInBasket",
                table: "FruitInBasket");

            migrationBuilder.RenameTable(
                name: "FruitInBasket",
                newName: "FruitInBasketsContext");

            migrationBuilder.RenameIndex(
                name: "IX_FruitInBasket_BasketId",
                table: "FruitInBasketsContext",
                newName: "IX_FruitInBasketsContext_BasketId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_FruitInBasketsContext",
                table: "FruitInBasketsContext",
                columns: new[] { "FruitId", "BasketId" });

            migrationBuilder.AddForeignKey(
                name: "FK_FruitInBasketsContext_Baskets_BasketId",
                table: "FruitInBasketsContext",
                column: "BasketId",
                principalTable: "Baskets",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_FruitInBasketsContext_Fruits_FruitId",
                table: "FruitInBasketsContext",
                column: "FruitId",
                principalTable: "Fruits",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FruitInBasketsContext_Baskets_BasketId",
                table: "FruitInBasketsContext");

            migrationBuilder.DropForeignKey(
                name: "FK_FruitInBasketsContext_Fruits_FruitId",
                table: "FruitInBasketsContext");

            migrationBuilder.DropPrimaryKey(
                name: "PK_FruitInBasketsContext",
                table: "FruitInBasketsContext");

            migrationBuilder.RenameTable(
                name: "FruitInBasketsContext",
                newName: "FruitInBasket");

            migrationBuilder.RenameIndex(
                name: "IX_FruitInBasketsContext_BasketId",
                table: "FruitInBasket",
                newName: "IX_FruitInBasket_BasketId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_FruitInBasket",
                table: "FruitInBasket",
                columns: new[] { "FruitId", "BasketId" });

            migrationBuilder.AddForeignKey(
                name: "FK_FruitInBasket_Baskets_BasketId",
                table: "FruitInBasket",
                column: "BasketId",
                principalTable: "Baskets",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_FruitInBasket_Fruits_FruitId",
                table: "FruitInBasket",
                column: "FruitId",
                principalTable: "Fruits",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
