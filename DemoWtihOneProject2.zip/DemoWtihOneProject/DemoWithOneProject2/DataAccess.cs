﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWithOneProject2
{
    public class DataAccess
    {
        private readonly FruitContext _context;

        public DataAccess()
        {
            _context = new FruitContext();
            //_context.Database.EnsureCreated();

        }

        internal List<Fruit> GetFruitsInCategory(string v)
        {
            var lista = _context.Fruits.Where(x => x.Category.Name == v).ToList();
            return lista;
        }

        internal void AddFruitsToBasket()
        {
            //var lista = _context.FruitInBasketsContext.Where(x => x.Fruit.Id == 1).Where(y => y.Basket.Id == 1).ToList();

            var nypon = new Fruit { Name = "Nypon" };
            var citron = new Fruit { Name = "Citron" };
            var mango = new Fruit { Name = "Mango" };
            //var basket3 = new Basket()
            //{
            //    Name = "Kundkorg3",
            //    FruitInBaskets = new List<FruitInBasket>()
            //    {
            //        new FruitInBasket { Fruit =  nypon }
            //    }

            //};

            Basket basket1 = _context.Baskets.Single(x => x.Name == "Kundkorg1");

            basket1.FruitInBaskets = new List<FruitInBasket>()
            {
                new FruitInBasket { Fruit =  citron }
            };

            Basket basket2 = _context.Baskets.Single(x => x.Name == "Kundkorg2");

            basket2.FruitInBaskets = new List<FruitInBasket>()
            {
                new FruitInBasket { Fruit =  mango }
            };

            //_context.Add(basket3);
            _context.Add(basket1);
            _context.Add(basket2);
            _context.SaveChanges();

        }

        internal IEnumerable<Fruit> GetAllFruitsInBasket(int id)
        {
            //return _context.Fruits.Include(x => x.FruitInBaskets).Where(i => i.Id == id);

    



            //return _context.Fruits.Where(i => i.FruitInBaskets.Any(x => x.BasketId == id));

        }

        internal IEnumerable<Basket> GetAllBaskets()
        {
            return _context.Baskets.Include(x => x.FruitInBaskets);
            //return _context.Baskets;
        }

        internal void AddBasket()
        {

            //var Basket1 = new Basket()
            //{
            //    Name = "Kundkorg1",
            //    FruitInBaskets = new List<FruitInBasket>()
            //    {
            //        new FruitInBasket { Fruit =   }
            //    }

            //};

            //var fib = new List<FruitInBasket>();
            //fib.Add(new FruitInBasket { Fruit = Appelsin });
            //fib.Add(new FruitInBasket { Fruit = nypon });

            var Basket1 = new Basket();
            Basket1.Name = "Kundkorg1";

            var Basket2 = new Basket();
            Basket2.Name = "Kundkorg2";



            _context.Baskets.Add(Basket1);
            _context.Baskets.Add(Basket2);

            //_context.FruitInBaskets.Add( { Basket = Basket1, FruitId = 1 });
            //_context.Fruits.Add(new FruitInBasket { Name = "Citron", Category = Category2 });

            _context.SaveChanges();

            


        }

        internal List<Fruit> GetAll()
        {
            var lista = _context.Fruits.Include(fruit => fruit.Category).ToList();
            return lista;
            //return _context.Fruits.Include(x => x.Category); Byt till Ienumarable
        }

        public void ClearDatabase()
        {
            foreach (Fruit item in _context.Fruits)
            {
                _context.Fruits.Remove(item);
            }

            foreach (FruitCategory item in _context.FruitCategories)
            {
                _context.FruitCategories.Remove(item);
            }
            _context.SaveChanges();
            //_context.Database.EnsureDeleted();
            //_context.Database.EnsureCreated();
        }

        internal void AddAFruit()
        {
            var Categories = _context.FruitCategories;
            _context.Fruits.Add(new Fruit { Name = "Appelsin", Category = Categories.First(), Price = 12 });
            _context.SaveChanges();

        }

        public void AddCategoriesAndFruits()
        {
            //var Category1 = new FruitCategory();
            //Category1.Name = "Stenfrukt";

            //var Category2 = new FruitCategory();
            //Category2.Name = "Citrusfrukter";

            var Category3 = new FruitCategory();
            Category3.Name = "Hejfrukt";

            //_context.FruitCategories.Add(Category1);
            //_context.FruitCategories.Add(Category2);
            _context.FruitCategories.Add(Category3);


            var päron = new Fruit { Name = "Päron", Price = 11, Category = Category3 };
            _context.Fruits.Add(päron);
            //_context.Fruits.Add(new Fruit { Name = "Äpple", Category = Category1 });
            //_context.Fruits.Add(new Fruit { Name = "Citron", Category = Category2});


            //var nypon = new Fruit { Name = "Nypon" };



            //FruitInBaskets = new List<FruitInBasket>()
            //{
            //    new FruitInBasket {Fruit =  nypon}
            //};



            _context.SaveChanges();

        }
    }
}
