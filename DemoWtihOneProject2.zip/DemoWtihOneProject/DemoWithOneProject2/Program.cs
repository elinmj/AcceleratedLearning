﻿using System;
using System.Collections.Generic;

namespace DemoWithOneProject2
{
    class Program
    {
        static void Main(string[] args)
        {
            //var dataAccess = new DataAccess();
            //dataAccess.AddCategoriesAndFruits();
            //Basket();
            //ClearAndInitDatabase();
            //DisplayStenfrukter();
            // DisplayAllFruits();
            //AddFruitsToBasket();
            DisplayBaskets();
            Console.ReadKey();
        }

        private static void DisplayBaskets()
        {
            var dataAccess = new DataAccess();
            IEnumerable<Basket> baskets = dataAccess.GetAllBaskets();

            foreach (var b in baskets)
            {
                Console.WriteLine();
                Console.WriteLine();

                Console.WriteLine("VARUKORG: " + b.Name);
                Console.WriteLine();

                IEnumerable<Fruit> fruits = dataAccess.GetAllFruitsInBasket(b.Id);

                foreach (var f in fruits)
                {
                    Console.WriteLine(f.Name);
                }
            }
        }
        private static void AddFruitsToBasket()
        {
            var dataAccess = new DataAccess();
            dataAccess.AddFruitsToBasket();
        }

        private static void Basket()
        {
            var dataAccess = new DataAccess();
            dataAccess.AddBasket();
        }

        private static void DisplayStenfrukter()
        {
            var dataAccess = new DataAccess();
            List<Fruit> fruits = dataAccess.GetFruitsInCategory("Stenfrukt");
            DisplayFruits(fruits);
            
        }

        private static void DisplayFruits(List<Fruit> fruits)
        {
            foreach (var fruit in fruits)
            {
                Console.WriteLine($"{fruit.Name.PadRight(10)}   {fruit.Price.ToString().PadLeft(15)}");
                // {fruit.Category.Name.PadRight(10)}
                //Console.WriteLine($"{fruit.Name,-15}  {fruit.Category.Name,-15}  {fruit.Price,-15}");
            }
        }

        private static void DisplayAllFruits()
        {
            var dataAccess = new DataAccess();
            var allFruits = dataAccess.GetAll();

            foreach (var fruit in allFruits)
            {
                Console.WriteLine($"{fruit.Name.PadRight(10)}  {fruit.Category.Name.PadRight(10)}  {fruit.Price.ToString().PadLeft(15)}");

                //Console.WriteLine($"{fruit.Name,-15}  {fruit.Category.Name,-15}  {fruit.Price,-15}");
            }
        }

        private static void ClearAndInitDatabase()
        {
            var dataAccess = new DataAccess();

            //dataAccess.ClearDatabase();
            //dataAccess.AddCategoriesAndFruits();
            dataAccess.AddAFruit();


        }
    }
}
