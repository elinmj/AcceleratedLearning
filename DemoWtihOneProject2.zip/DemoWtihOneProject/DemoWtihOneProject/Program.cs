﻿using System;

namespace DemoWtihOneProject
{
    class Program
    {
        static void Main(string[] args)
        {
            FruitContext context = new FruitContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            //var newfruit = new Frukt
            //{
            //    Name = "Banan"
            //};

           // context.Fruits.Add(newfruit);
            context.Fruits.Add(new Frukt { Name = "Äpple" , Color = "Grönt"});

            context.SaveChanges();


            foreach (var fruit in context.Fruits)
            {
                Console.WriteLine(fruit.Id + " " + fruit.Name + " " + fruit.Color);
            }
            Console.ReadKey();
        }
    }
}
