


	window.alert("Hej du!");


function myFunction(){
	document.getElementById("tmp").innerHTML = "Blaaa";
}


