﻿namespace MethodsAndLists.Core.Models
{
    public class City
    {
        public string Name { get; set; }
        public int Population { get; set; }
    }
}
