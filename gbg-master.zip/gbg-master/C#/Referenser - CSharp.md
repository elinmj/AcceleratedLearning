# Referenser i C#

## Dot Net Pearls
https://www.dotnetperls.com/

## Tutorial Point
https://www.tutorialspoint.com/csharp/

## Microsoft tutorial
https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/

## C# Yellow Book (gratis bok, 200s)
http://www.robmiles.com/c-yellow-book/

## Videokurser (betal)
https://www.pontwitt.com/courses/c-sharp-and-net-core-for-beginners

## Basics
- https://www.learncs.org/
- https://www.sololearn.com/Course/CSharp/
- https://csharpskolan.se/article/

## Shortcuts
- https://docs.google.com/document/d/12yWSfpxIh3XXUfrG2xZB9eusDZHOBBFiggM-tddTzFM/ 
- https://www.youtube.com/watch?v=r4OunLmSMAU 
