﻿namespace M4_Methods
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
            //// 4.1 Creating methods

            //Exercise4_1_no_methods.Run();
            //Exercise4_1.Run();

            //// 4.2 Clean user input

            //Exercise4_2.Run();

            ////  4.3 Validation
            Exercise4_3.Run();

            //// 4.4 More options
            //Exercise4_4.Run();

            //Exercise4_4_Alternative.Run();

        }
    }
}
