﻿namespace M7_Inheritance
{
    public abstract class Shape
    {
        public abstract double CalculateArea();

        public override string ToString()
        {
            return "I'm a shape";
        }
    }
}
