All info om inl�mningsuppgiften hittar du h�r:

https://github.com/happy-bits/itch/blob/master/Checkpoints/Checkpoint0/produktlista.md (L�nkar till en externa sida.)L�nkar till en externa sida.

Instruktioner f�r inl�mning

Skapa en zip-fil av ditt program (ta g�rna bort mapparna bin, obj och .vs).

L�mna in zip-filen h�r i Canvas

Deadline: s�ndag 22:e juli kl 23:59

PS

"Niv� 3" �r mycket sv�r och jag f�rv�ntar mig inte att ni l�st uppgiften. Men g�r ett f�rs�k och l�mna in s� l�ng du hinner.

Lycka till!