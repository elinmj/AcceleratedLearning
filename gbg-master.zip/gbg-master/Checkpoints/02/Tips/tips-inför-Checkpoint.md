# Tips inf�r checkpoint

�va p�:

- Att omvandla en str�ng till en lista av egna objekt. Som t.ex **ParseCities**
- Uppgifterna vi gjort i **MethodsAndLists**

Dessutom det vi tidigare gjort:

- Console.ReadLine
- Console.WriteLine
- Split
- Omvandla v�rden till annan typ (t.ex int.Parse)
- Loopar (for, foreach, while)
- Metoder
- Listor
